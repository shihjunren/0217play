﻿let theYear = document.querySelector("#idSelectYear");
let theMonth = document.querySelector("#idSelectMonth");
let theDay = document.querySelector("#idSelectDay");
let yy, mm, d, dno, dNow = 1;
let myDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
theYear.addEventListener("change", addDay);
theMonth.addEventListener("change", addDay);
theDay.addEventListener("change", setDay);
theDay.addEventListener("blur", setDay);

let docFrag = document.createDocumentFragment();
for (let i = 2010; i <= 2030; i++) {   //新增年
    let opt = document.createElement("option");
    opt.setAttribute("value", i);
    let optTxt = document.createTextNode(i);
    opt.appendChild(optTxt);
    docFrag.appendChild(opt);
}
theYear.appendChild(docFrag);

docFrag = document.createDocumentFragment();
for (let i = 1; i <= 12; i++) {   //新增月
    let opt = document.createElement("option");
    opt.setAttribute("value", i);
    let optTxt = document.createTextNode(i);
    opt.appendChild(optTxt);
    docFrag.appendChild(opt);
}
theMonth.appendChild(docFrag);

function addDay() {
    yy = theYear.value;
    mm = theMonth.value;
    //console.log(yy, mm);
    let d = new Date(yy, mm, 0);
    dno = d.getDate();
    //console.log(dno);
    //console.log(theDay.firstChild);
    while (theDay.firstChild) {
        theDay.removeChild(theDay.firstChild);
    }
    for (let i = 1; i <= dno; i++) {
        let opt = document.createElement("option");
        opt.setAttribute("value", i);
        let optTxt = document.createTextNode(i);
        opt.appendChild(optTxt);
        docFrag.appendChild(opt);
    }
    theDay.appendChild(docFrag);
    
    if (dNow > theDay.children.length) {
        dNow = theDay.children.length;
    }
    showDate();
    showTable();
    theDay.children[dNow - 1].setAttribute("selected", "selected");
}
addDay();
function setDay() {
    dNow = theDay.value;
    showDate();
    showTable();
}
function showDate() {
    let spDate = document.querySelector("#spDate");
    spDate.innerHTML = `選擇的日期是${yy}年${mm}月${dNow}日`;
}
function showTable() {
    let theTable = document.querySelector("#idTable");
    while (theTable.firstChild) {
        theTable.removeChild(theTable.firstChild);
    }
    let d = new Date(yy, mm - 1, 1);
    let day = d.getDay();
    let rowNum = Math.ceil((day + dno) / 7) + 1;
    console.log(rowNum)
    for (let i = 0; i < rowNum; i++) {
        let tr = document.createElement("tr");
        for (let j = 0; j < 7; j++) {
            let td = document.createElement("td");
            if (i == 0) {
                td.innerHTML = myDays[j];
            } else if (i * 7 + j - 6 - day > 0 && i * 7 + j - 6 - day <= dno) {
                td.innerHTML = i * 7 + j - 6 - day;
                td.addEventListener("click", selectDay);
                if (i * 7 + j - 6 - day == dNow) {
                    td.setAttribute("style", "background-color: rgb(255,0,0,0.3)");
                }
            }
            tr.appendChild(td);
        }
        docFrag.appendChild(tr);
    }
    theTable.appendChild(docFrag);
}
function selectDay() {
    //console.log(this.innerHTML);
    dNow = this.innerHTML;
    showDate();
    showTable();
    for (let item of theDay) {
        item.removeAttribute("selected");
    }
    theDay.children[dNow - 1].setAttribute("selected", "selected");
}