﻿namespace SimpleWebside.Controllers
{
    public class Parameter
    {
        public string? Name { get; set; }
    }
}

// ?問號屬性，允許Name沒有值。